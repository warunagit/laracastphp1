<?php
$host = "localhost";
$username = "root";
$password = "1234";
$dbname = "mazzm";
?>