<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Cinemotography | M.Assam | Mazzm.com</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="mazzm,mazzm.com,qatar,sri lanka,mohamed,assam,azzam,video,videographer,videography,cinema,cinematography,photo,photography,doha,doha film school"/>
<meta name="description" content="Im an 1st/2nd Assistant Camera based on Qatar, from Sri Lanka. Contact me: +974 6682 7121, +974 30 31 1511" />
<meta name="auther" content="Yasantha WB" />
<link rel="shortcut icon" href="assests/image/mazzm.png">

<link type="text/css" href="assests/css/bootstrap.min.css" rel="stylesheet">
<link type="text/css" href="assests/css/bootstrap-theme.min.css" rel="stylesheet">
<link type="text/css" href="assests/css/normalizee.css" rel="stylesheet">

<link type="text/css" href="assests/css/pe-icon-7-stroke.css" rel="stylesheet" />
<link type="text/css" href="assests/css/ct-navbar.css" rel="stylesheet" />

<link type="text/css" href="assests/css/cinemotography.css" rel="stylesheet">
<link type="text/css" href="assests/css/cinemotography_responsive.css" rel="stylesheet" media="screen">

</head>

<body onLoad=="set();">
<!-- Navigation -->
    <nav class="navbar navbar-ct-blue navbar-fixed-top navbar-transparent" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <center>
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </center>
                </button>
                <a class="navbar-brand" href="mazzm_mazzm">Mazzm.com</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
               <ul class="nav navbar-nav">
                    <li>
                        <a href="mazzm_assistant_camera">
                        	<i class="pe-7s-albums"></i>
                            <p>Assistant Camera</p>
                        </a>
                    </li>
                    <li>
                        <a href="mazzm_filmography">
                        	<i class="pe-7s-portfolio"></i>
                            <p>Filmography</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="">
                        	<i class="pe-7s-portfolio"></i>
                            <p>Work</p>
                        </a>
                    </li>
                    
                    <li>
                        <a href="mazzm_contact">
                        	<i class="pe-7s-call"></i>
                            <p>Contact</p>
                        </a>
                    </li>    
                    <li>
                        <a href="http://qa.linkedin.com/in/mazzmassam" target="_blank">
                        	<i class="pe-7s-call"></i>
                            <p>Profile</p>
                        </a>
                    </li>                
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

<div class="content">
<div class="jumbo">
	<div id="viewer">
    	<div id="desc">
        	<div class="vdesc" id="ttl"></div>
            <div class="vdesc" id="txt">Job Roll</div>
            <div class="vdesc" id="jrl"></div>
            <div class="vdesc" id="txt">Distribution</div>
            <div class="vdesc" id="dtrb"></div>
            <div class="vdesc" id="txt" id="l">Links</div>
            <div class="vdesc" id="lnks""></div>
        </div>
    	<iframe id="ifrm"></iframe>
    </div>
    
    <div id="thumbs"> 
    
		<?php
			require_once "controll/mysql_conf.php";
			$conn = mysqli_connect($host, $username, $password, $dbname);
            $sql = "SELECT * FROM tbl4_cinematography ORDER BY id DESC";
            $result = mysqli_query($conn, $sql);
                
            while($row = mysqli_fetch_array($result)) {
        ?>
              
                <img src="assests/image/works/cinematography/<?php echo $row['id'];?>.jpg"
                    data-link="<?php echo $row['mainlink'];?>" 
                    data-ttl="<?php echo $row['title'];?>"
                    data-jrl="<?php echo $row['jobroll'];?>"
                    data-dtrb="<?php echo $row['distribution'];?>"
             		data-lnks="<?php echo $row['sublinks'];?>"
        />
       <?php 
        	}
        ?>
        
    </div>
</div>
</div>

<script type="text/javascript" src="assests/js/jquery.js"></script>
<script type="text/javascript" src="assests/js/bootstrap.min.js"></script>
<script type="text/javascript">
	resize();
	$("document").ready(function(){
		$("img:nth-child(1)").click();	
	});
	function set(){
		if($(window).width()>600){	
			resize();
		}		
	}
	function resize(){				
		var w = $("#viewer iframe").width();
		var h = (w/16)*9;
		$("#viewer iframe").css("height",h+"px");			
		/*if($(window).width()>600){$("#thumbs").css("height",$("#viewer iframe").height());}*/
	};	
	$("#thumbs img").click(function(){
		var x = this.dataset.link;
		document.getElementById("ifrm").src=x;			
		x = this.dataset.ttl;
		document.getElementById("ttl").innerHTML=x;
		x = this.dataset.jrl;
		document.getElementById("jrl").innerHTML=x
		x = this.dataset.dtrb;
		document.getElementById("dtrb").innerHTML=x
		x = this.dataset.lnks;
		document.getElementById("lnks").innerHTML=x
		$("html,body").animate({scrollTop :0},"slow");		
	});
</script>
<script type="text/javascript" src="assests/js/ct-navbar.js"></script>
</body>
</html>