<?php
	
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<style>body{padding-top: 60px;}</style>
	
    <link href="bootstrap3/css/bootstrap.css" rel="stylesheet" />
 
	<link href="login-register.css" rel="stylesheet" />
	<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
	
	<script src="jquery/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="bootstrap3/js/bootstrap.js" type="text/javascript"></script>
	<script src="login-register.js" type="text/javascript"></script>
	<script type="text/javascript">
    	openLoginModal();
    </script>
</head>
<body>
    <div class="container">       
         
		 <div class="modal" id="loginModal">
		      <div class="modal-dialog login">
    		      <div class="modal-content">
    		         <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Login Key</h4>
                    </div>
                    <div class="modal-body">  
                        <div class="box">
                             <div class="content">
                                <div class="division">
                                    <div class="line l"></div>
                                      <span></span>
                                    <div class="line r"></div>
                                </div>
                                <div class="error">
                                <?php
								//echo 'hooooooooo'.md5('m@26*2#');
									$i=0;            
									require_once "../controll/mysql_conf.php";
						            $conn = mysqli_connect($host, $username, $password, $dbname);

									if(isset($_POST['password'])){
										if (!$conn) {
											die("<span class='mer'>Connection failed: " . mysqli_connect_error()."</span>");
										}
										
										$sql = "SELECT * FROM log_user LIMIT 1";
										$result = mysqli_query($conn, $sql);
										$row = mysqli_fetch_assoc($result);
										
											if($row['key'] == md5($_POST['password'])){
												session_start();
												$_SESSION['statee'] = 'activee';
												header('Location:../controll/mazzm_mazzm.php');
											}else{
												$i = $i+1;
												echo '<div class="col-md-12 alert-danger"><center>Invalid Key</center></div>';
												if($i>2){
													session_unset();
													session_destroy(); 
													header('Location:http://www.mazzm.com');
													//redirect_to('Location:http://www.mazzm.com');
												}
											}	
										
									}
								?>
                                </div>
                                <div class="form loginBox ">
                                    <form method="post" action="<?php echo htmlentities($_SERVER["PHP_SELF"]); ?>" accept-charset="UTF-8">
                                    <input id="password" class="form-control" type="password" placeholder="Login Key" name="password">
                                    <input class="btn btn-default btn-login" type="submit" value="Login">
                                    </form>
                                </div>
                             </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="forgot login-footer">
                            <span>Back to 
                                 <a href="http://www.mazzm.com">mazzm.com</a>
                            </span>
                        </div>
                    </div>        
    		      </div>
		      </div>
		  </div>
    </div>
</body>
</html>


