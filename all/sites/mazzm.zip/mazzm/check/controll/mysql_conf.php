<?php
$host = "localhost";
$username = "mazzmc6_mzm";
$password = "mazzm123#";
$dbname = "mazzmc6_mazzm_db2";
?>