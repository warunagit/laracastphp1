﻿<?php
		require_once "controll/mysql_conf.php";
		$conn = mysqli_connect($host, $username, $password, $dbname);
		
		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
		}
		$sql = "SELECT * FROM `tbl1_mazzm`";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($result);
	?>
<?php "CACHE-CONTROL: no-cache,no-cache,must-revalidate" ?>
<?php "CACHE-CONTROL: post-check=0,pre-check=0" ?>
<?php "Pragma: no-cache"?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="mazzm,mazzm.com,qatar,sri lanka,mohamed,assam,azzam,video,videographer,videography,cinema,cinematography,photo,photography,doha,doha film school"/>
<meta name="description" content="Im an 1st/2nd Assistant Camera based on Qatar, from Sri Lanka. Contact me: +974 6682 7121, +974 30 31 1511" />
<meta name="auther" content="Yasantha WB" />
    <link rel="shortcut icon" href="assests/image/mazzm.png">

    <title>I am Assam M. | Mazzm.com</title>

    <link href="assests/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="assests/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link type="text/css" href="assests/css/ct-navbar.css" rel="stylesheet" />
    <link href="assests/css/cover.css" rel="stylesheet">
    <link href="assests/css/bootstrap-social.css" rel="stylesheet">
    <link href="assests/css/docs.css" rel="stylesheet">
    <link href="assests/css/font-awesome.css" rel="stylesheet">
    

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
  </head>

  <body>
   <!-- Navigation -->
    <nav class="navbar navbar-ct-blue navbar-fixed-top navbar-transparent" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <center>
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </center>
                </button>
                <a class="navbar-brand" href="#">Mazzm.com</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                 <ul class="nav navbar-nav">
                    <li>
                        <a href="mazzm_assistant_camera">
                        	<i class="pe-7s-albums"></i>
                            <p>Assistant Camera</p>
                        </a>
                    </li>
                    <li>
                        <a href="mazzm_filmography">
                        	<i class="pe-7s-portfolio"></i>
                            <p>Filmography</p>
                        </a>
                    </li>
                    <li>
                        <a href="mazzm_cinemotography">
                        	<i class="pe-7s-portfolio"></i>
                            <p>Work</p>
                        </a>                        
                    </li>
                    
                    <li>
                        <a href="mazzm_contact">
                        	<i class="pe-7s-call"></i>
                            <p>Contact</p>
                        </a>
                    </li>   
                    <li>
                        <a href="http://qa.linkedin.com/in/mazzmassam" target="_blank">
                        	<i class="pe-7s-call"></i>
                            <p>Profile</p>
                        </a>
                    </li>                 
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
  
  
  
  <div class="container land">
    <div class="row">
        <div class="col-md-5">
           <img class="mini_image"/>
        </div>
        <div class="col-md-7">
            <div class="inner cover">
            <h1 class="cover-heading"><?php echo $row['title1']; ?></h1>
            <h2><b><?php echo $row['title2']; ?></b></h2>
            <hr/>
            <p class="lead"><?php echo $row['text1']; ?></p>

			<p class="lead"><?php echo $row['text2']; ?></p>


            <p class="lead">
              <a href="mazzm_assistant_camera" class="btn btn-lg btn-default">More about me.</a>
            </p>
            
            <div class="mastfoot">
                <div class="inner">
                  <!--<p>Cover template for <a href="http://getbootstrap.com">Bootstrap</a>, by <a href="https://twitter.com/mdo">@mdo</a>.</p>-->
                    <a class="btn btn-social-icon btn-linkedin"><i class="fa fa-linkedin"></i></a>
                    <a class="btn btn-social-icon btn-facebook"><i class="fa fa-facebook"></i></a>
                    <a class="btn btn-social-icon btn-instagram"><i class="fa fa-instagram"></i></a>
                    <a class="btn btn-social-icon btn-vimeo"><i class="fa fa-vimeo-square"></i></a>               
                </div>
          	</div>          
        </div>          
          
    </div>
</div>


 


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
<script type="text/javascript" src="assests/js/jquery.js"></script>
<script type="text/javascript" src="assests/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assests/js/docs.js"></script>
  </body>
</html>
