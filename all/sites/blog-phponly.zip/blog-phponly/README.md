# PHP File Blog

Blog engine written in PHP, using plaintext csv files instead of databases to store posts.

This is a very basic product.  I did this within the space of about a day, in 2013, when I was learning PHP.

No warranty or support will be provided for this, and it is posted here for demonstration purposes only.  If you want a CMS or Blog Engine that does not use a conventional databse, try out one of any of the dozens of professionally-made and supported Content Management Systems out there.  Furthermore, if you simply want this functinality, a Static type of blog layout that you have to manually push updates to, maybe look into Static Site Generators, many of which already exist and are popular (I'm working with Jekyll right now, which is a really fantastic example of a static website generator that operates on the server side and works great for blogs).  Really, you shouldn't need server-side code at all to deploy a simple blog.  
