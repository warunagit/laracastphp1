<?php
$page="404";
include "views/404.view.php";