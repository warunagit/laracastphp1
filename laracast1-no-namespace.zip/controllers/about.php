<?php

view("about.view.php",['page'=>"About"]);