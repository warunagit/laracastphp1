<?php

view("contact.view.php",['page'=>"Contact"]);