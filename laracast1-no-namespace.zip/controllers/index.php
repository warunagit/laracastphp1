<?php

view("index.view.php",['page'=>"Index"]);