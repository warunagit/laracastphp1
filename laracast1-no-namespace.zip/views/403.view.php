<?php
require "partials/header.php";
require "partials/nav.php";
?>
<div class="pt-24 text-black">
    <p>Access Forbidden!</p>
    <a href="/">Back</a>
</div>
